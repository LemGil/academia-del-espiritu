import { useState, useEffect } from "react";
import {
  getCursos,
  createCurso,
  updateCurso,
  deleteCurso,
} from "../services/cursosService";

export function useCursos(nivelId = null) {
  const [cursos, setCursos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editingCurso, setEditingCurso] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  async function fetchCursos() {
    setLoading(true);
    const { data, error } = await getCursos(nivelId);
    if (error) console.error("Error cargando cursos:", error.message);
    setCursos(data || []);
    setLoading(false);
  }

  useEffect(() => {
    fetchCursos();
  }, [nivelId]);

  async function addCurso(curso, imagenFile) {
    setSaving(true);
    // imagen_url: pendiente de implementar subida a Supabase Storage
    const payload = { ...curso, nivel_id: nivelId };
    const { error } = await createCurso(payload);
    if (error) console.error("Error creando curso:", error.message);
    await fetchCursos();
    setSaving(false);
  }

  async function editCurso(id, updates, imagenFile) {
    setSaving(true);
    // imagen_url: pendiente de implementar subida a Supabase Storage
    const { error } = await updateCurso(id, updates);
    if (error) console.error("Error actualizando curso:", error.message);
    await fetchCursos();
    setSaving(false);
  }

  async function removeCurso(id) {
    const { error } = await deleteCurso(id);
    if (error) console.error("Error eliminando curso:", error.message);
    await fetchCursos();
  }

  function startEdit(curso) {
    setEditingCurso(curso);
    setIsModalOpen(true);
  }

  function startCreate() {
    setEditingCurso(null);
    setIsModalOpen(true);
  }

  function closeModal() {
    setEditingCurso(null);
    setIsModalOpen(false);
  }

  return {
    cursos,
    loading,
    saving,
    addCurso,
    editCurso,
    removeCurso,
    editingCurso,
    isModalOpen,
    startEdit,
    startCreate,
    closeModal,
  };
}
